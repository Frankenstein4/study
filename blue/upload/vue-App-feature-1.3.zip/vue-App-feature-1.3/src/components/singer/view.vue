<template>
  <div>歌手</div>
</template>
<script>

</script>
<style>

</style>
