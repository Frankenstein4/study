export const configParams = {
  g_tk: 1045926340,
  uin: 1871733910,
  inCharset: 'utf-8',
  outCharset: 'utf-8',
  format: 'json',
  notice: 0,
  needNewCode: 1
}

export const options = {
  param: 'jsonpCallback'
}

export const ERR_OK = 0
