# music-app

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev
```

项目的开始，先梳理好项目的结构，[点击查看详情](https://searworld.gitbooks.io/vux/content/fen-xi-xiang-mu-gong-cheng-jie-gou.html)
